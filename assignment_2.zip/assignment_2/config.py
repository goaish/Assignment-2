# config.py

"""
Configuration settings for the LLM Factual Correctness and Hallucination Detection System.
This file centralizes paths, LLM model configurations, and evaluation settings.
"""

import os

# --- File Paths ---
# Path to the JSON file containing test data (prompts, reference contexts, expected outputs).
DATA_FILE = 'data.json'

# Directory where test results and reports will be saved.
RESULTS_DIR = 'test_results_factual'
os.makedirs(RESULTS_DIR, exist_ok=True) # Ensure the directory exists

# --- LLM Settings ---
# List of LLM models to be used for testing. Each dictionary represents a model.
# 'name': A unique identifier for the model (e.g., 'Gemini Flash', 'Llama 2 7B Chat').
# 'model_id': The actual model identifier used in the API call or local server.
#             For open-source models, this might be a Hugging Face model ID,
#             or a local endpoint identifier (e.g., 'llama2' if using Ollama).
# 'api_key': The API key for this specific model. Can be empty if not required
#            (e.g., for locally served open-source models) or if handled by environment.
#            For Canvas, it's left empty for Google models as Canvas injects it.
# 'api_endpoint': (Optional) The base URL for the model's API if different from default.
#                 Useful for self-hosted or different inference APIs.
LLM_MODELS_CONFIGS = [
    {
        "name": "Gemini Flash",
        "model_id": "gemini-2.0-flash",
        "api_key": "" # Canvas will inject this at runtime for Google models
    },
    {
        "name": "Llama 2 7B Chat (Simulated)", # Renamed to clarify simulation
        "model_id": "meta-llama/Llama-2-7b-chat-hf",
        "api_key": "YOUR_HUGGINGFACE_API_KEY_HERE", # Placeholder for real use
        "api_endpoint": "https://api-inference.huggingface.co/models/" # Placeholder for real use
    },
    {
        "name": "Mistral 7B Instruct (Simulated)", # Renamed to clarify simulation
        "model_id": "mistralai/Mistral-7B-Instruct-v0.2",
        "api_key": "YOUR_HUGGINGFACE_API_KEY_HERE", # Placeholder for real use
        "api_endpoint": "https://api-inference.huggingface.co/models/" # Placeholder for real use
    }
]

# --- Fact-Checking Settings ---
# Minimum length for a statement to be considered for individual fact-checking.
# Shorter statements might be too trivial or hard to verify contextually.
MIN_STATEMENT_LENGTH = 10

# Threshold for considering a response "correct" based on supported statements percentage.
# E.g., if 80% of statements are supported, the overall response is considered correct.
OVERALL_CORRECTNESS_THRESHOLD = 0.75 # 75% of statements must be supported for overall pass

# Threshold for considering a response "hallucinated" based on hallucinated statements percentage.
# E.g., if more than 10% of statements are hallucinated, flag as significant hallucination.
OVERALL_HALLUCINATION_THRESHOLD = 0.10 # 10% of statements being hallucinated is significant
