# reporting.py

"""
Generates comprehensive reports based on the factual correctness and hallucination analysis.
Provides summaries and detailed breakdowns for each LLM model tested.
"""

from typing import List, Dict, Any
from fact_checker import FactCheckResult
import os
from datetime import datetime

def generate_factual_report(
    model_name: str,
    test_results: List[Dict[str, Any]], # List of results, each containing 'analysis' and 'test_data_id'
    results_dir: str
) -> str:
    """
    Generates a text-based report for factual correctness and hallucination.

    Args:
        model_name (str): The name of the LLM model for which the report is being generated.
        test_results (List[Dict[str, Any]]): A list of dictionaries, where each dict
                                              contains the 'analysis' (from fact_checker)
                                              and 'test_data_id'.
        results_dir (str): The directory where the report file should be saved.

    Returns:
        str: The path to the generated report file.
    """
    total_test_cases = len(test_results)
    total_correct_statements = 0
    total_hallucinated_statements = 0
    total_unverifiable_statements = 0
    total_statements_overall = 0

    hallucination_flagged_cases = []
    low_correctness_flagged_cases = []

    for res in test_results:
        analysis = res['analysis']
        test_data_id = res['test_data_id']
        llm_output = res['llm_output']
        reference_context = res['reference_context']

        total_statements_overall += analysis["total_statements"]
        total_correct_statements += analysis["correct_statements"]
        total_hallucinated_statements += analysis["hallucinated_statements"]
        total_unverifiable_statements += analysis["unverifiable_statements"]

        if analysis["overall_status"] == "Fail: High hallucination":
            hallucination_flagged_cases.append({
                "id": test_data_id,
                "llm_output": llm_output,
                "hallucinated_percentage": analysis["hallucinated_percentage"],
                "details": analysis["detailed_results"]
            })
        if analysis["overall_status"] == "Fail: Low correctness":
            low_correctness_flagged_cases.append({
                "id": test_data_id,
                "llm_output": llm_output,
                "correct_percentage": analysis["correct_percentage"],
                "details": analysis["detailed_results"]
            })

    # Calculate overall percentages
    overall_correct_percentage = (total_correct_statements / total_statements_overall * 100) if total_statements_overall > 0 else 0.0
    overall_hallucinated_percentage = (total_hallucinated_statements / total_statements_overall * 100) if total_statements_overall > 0 else 0.0
    overall_unverifiable_percentage = (total_unverifiable_statements / total_statements_overall * 100) if total_statements_overall > 0 else 0.0

    report_content = []
    report_content.append("--- LLM Factual Correctness & Hallucination Report ---")
    report_content.append(f"Model Tested: {model_name}")
    report_content.append(f"Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    report_content.append("-" * 60)
    report_content.append("\n--- Overall Summary ---")
    report_content.append(f"Total Test Cases Processed: {total_test_cases}")
    report_content.append(f"Total Statements Analyzed: {total_statements_overall}")
    report_content.append(f"Statements Correctly Supported: {total_correct_statements} ({overall_correct_percentage:.2f}%)")
    report_content.append(f"Statements Hallucinated: {total_hallucinated_statements} ({overall_hallucinated_percentage:.2f}%)")
    report_content.append(f"Statements Unverifiable: {total_unverifiable_statements} ({overall_unverifiable_percentage:.2f}%)")
    report_content.append("-" * 60)

    if hallucination_flagged_cases:
        report_content.append("\n--- Cases Flagged for High Hallucination ---")
        for case in hallucination_flagged_cases:
            report_content.append(f"\nTest Data ID: {case['id']}")
            report_content.append(f"  LLM Output: {case['llm_output']}")
            report_content.append(f"  Hallucinated Statements: {case['hallucinated_percentage']:.2f}%")
            report_content.append("  Detailed Statement Analysis:")
            for detail in case['details']:
                report_content.append(f"    - '{detail['statement']}' Status: {detail['status']} (Reason: {detail['justification']})")
                if detail['evidence']:
                    report_content.append(f"      Evidence: '{detail['evidence']}'")
            report_content.append("-" * 40)
    else:
        report_content.append("\nNo cases flagged for high hallucination.")

    if low_correctness_flagged_cases:
        report_content.append("\n--- Cases Flagged for Low Correctness ---")
        for case in low_correctness_flagged_cases:
            report_content.append(f"\nTest Data ID: {case['id']}")
            report_content.append(f"  LLM Output: {case['llm_output']}")
            report_content.append(f"  Correct Statements: {case['correct_percentage']:.2f}%")
            report_content.append("  Detailed Statement Analysis:")
            for detail in case['details']:
                report_content.append(f"    - '{detail['statement']}' Status: {detail['status']} (Reason: {detail['justification']})")
                if detail['evidence']:
                    report_content.append(f"      Evidence: '{detail['evidence']}'")
            report_content.append("-" * 40)
    else:
        report_content.append("\nNo cases flagged for low correctness.")

    report_filename = f"factual_report_{model_name.replace(' ', '_').lower()}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
    report_filepath = os.path.join(results_dir, report_filename)

    try:
        with open(report_filepath, 'w', encoding='utf-8') as f:
            f.write("\n".join(report_content))
        print(f"\nReport generated successfully for {model_name}: {report_filepath}")
    except IOError as e:
        print(f"Error writing report for {model_name} to file {report_filepath}: {e}")
        report_filepath = "" # Indicate failure to save

    return report_filepath

if __name__ == '__main__':
    # Example usage:
    # This block demonstrates how to use the generate_factual_report function.
    from fact_checker import analyze_factual_correctness_and_hallucination

    # Create a dummy results directory if it doesn't exist
    dummy_results_dir = "dummy_factual_reports"
    os.makedirs(dummy_results_dir, exist_ok=True)

    # Simulate some analysis results
    context_heart = "The human heart is a muscular organ that pumps blood throughout the body via the circulatory system, supplying oxygen and nutrients to the tissues and removing carbon dioxide and other wastes."
    output_heart_good = "The heart pumps blood to provide oxygen and nutrients and remove waste."
    output_heart_bad = "The heart pumps blood and also produces insulin." # Hallucination

    analysis_good = analyze_factual_correctness_and_hallucination(output_heart_good, context_heart)
    analysis_bad = analyze_factual_correctness_and_hallucination(output_heart_bad, context_heart)

    mock_test_results = [
        {
            "test_data_id": "FACT_001_GOOD",
            "llm_output": output_heart_good,
            "reference_context": context_heart,
            "analysis": analysis_good
        },
        {
            "test_data_id": "FACT_002_BAD",
            "llm_output": output_heart_bad,
            "reference_context": context_heart,
            "analysis": analysis_bad
        }
    ]

    print("--- Generating example factual report ---")
    report_file = generate_factual_report("Example LLM Model", mock_test_results, dummy_results_dir)
    if report_file:
        with open(report_file, 'r', encoding='utf-8') as f:
            print("\n--- Report Content ---")
            print(f.read())
            print("--- End Report Content ---")
