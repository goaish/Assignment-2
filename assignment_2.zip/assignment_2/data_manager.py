# data_manager.py

"""
Manages the loading and structuring of test data for the LLM factual correctness evaluation.
Test data, including prompts, reference contexts, and expected outputs, are read from a JSON file.
"""

import json
from dataclasses import dataclass, field
from typing import List, Dict, Any

@dataclass
class TestData:
    """
    Represents a single test data entry for LLM factual correctness evaluation.

    Attributes:
        id (str): A unique identifier for the test data.
        prompt (str): The input prompt to send to the LLM.
        reference_context (str): The factual context against which the LLM's output will be checked.
        expected_output (str): The anticipated correct output from the LLM based SOLELY on the reference_context.
        metadata (Dict[str, Any]): Any additional, arbitrary metadata for the test data.
    """
    id: str
    prompt: str
    reference_context: str
    expected_output: str
    metadata: Dict[str, Any] = field(default_factory=dict)

def load_test_data(file_path: str) -> List[TestData]:
    """
    Loads test data from a specified JSON file.

    Args:
        file_path (str): The path to the JSON file containing the test data.

    Returns:
        List[TestData]: A list of TestData objects.

    Raises:
        FileNotFoundError: If the specified file does not exist.
        json.JSONDecodeError: If the file content is not valid JSON.
        ValueError: If the JSON structure is not as expected for test data.
    """
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
    except FileNotFoundError:
        print(f"Error: Test data file not found at {file_path}")
        raise
    except json.JSONDecodeError:
        print(f"Error: Invalid JSON format in {file_path}")
        raise

    test_data_list = []
    for item in data:
        try:
            # Ensure required fields are present
            if not all(k in item for k in ['id', 'prompt', 'reference_context', 'expected_output']):
                raise ValueError(f"Missing required fields in test data entry: {item}")

            test_data_list.append(TestData(
                id=item['id'],
                prompt=item['prompt'],
                reference_context=item['reference_context'],
                expected_output=item['expected_output'],
                metadata=item.get('metadata', {})
            ))
        except KeyError as e:
            print(f"Error: Missing key {e} in test data entry: {item}")
            continue
        except ValueError as e:
            print(f"Error processing test data entry: {e}")
            continue
    return test_data_list

if __name__ == '__main__':
    # Example usage:
    # This block demonstrates how to use the load_test_data function.
    # In a real scenario, data.json would be populated with actual data.
    example_data_content = [
        {
            "id": "DEMO_001",
            "prompt": "What is the capital of France?",
            "reference_context": "Paris is the capital and most populous city of France.",
            "expected_output": "Paris is the capital of France."
        },
        {
            "id": "DEMO_002",
            "prompt": "Who invented the light bulb?",
            "reference_context": "While Thomas Edison is often credited with the invention of the light bulb, many inventors contributed to its development.",
            "expected_output": "Thomas Edison is often credited with the invention of the light bulb, though many contributed."
        }
    ]
    # Create a dummy data.json for demonstration
    with open('data.json', 'w', encoding='utf-8') as f:
        json.dump(example_data_content, f, indent=4)

    try:
        loaded_data = load_test_data('data.json')
        print(f"Loaded {len(loaded_data)} test data entries:")
        for td in loaded_data:
            print(f"  ID: {td.id}, Prompt: '{td.prompt[:50]}...', Context: '{td.reference_context[:50]}...'")
    except Exception as e:
        print(f"Failed to load test data: {e}")
