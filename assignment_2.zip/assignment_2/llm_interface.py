# llm_interface.py

"""
Provides an interface to interact with various LLM (Large Language Model) APIs.
This module handles the API calls to the specified LLM,
abstracting the communication details from the rest of the system.
It is designed to be adaptable for different LLM providers (e.g., Google, Hugging Face, local servers).
"""

import json
import time # For simulating loading time
import random # For simulating varied responses

class LLMInterface:
    """
    Handles communication with a specific LLM model, adapting to different API endpoints.
    """
    def __init__(self, model_id: str, api_key: str = "", api_endpoint: str = None):
        """
        Initializes the LLMInterface with the model ID, API key, and an optional custom API endpoint.

        Args:
            model_id (str): The ID of the LLM model to interact with (e.g., 'gemini-2.0-flash', 'meta-llama/Llama-2-7b-chat-hf').
            api_key (str): The API key for authentication with the LLM service.
                           In this Canvas environment, it's typically injected at runtime for Google models.
            api_endpoint (str, optional): The base URL for the model's API.
                                          If None, defaults to Google's Generative Language API.
                                          Set this for other providers (e.g., Hugging Face, local Ollama).
        """
        self.model_id = model_id
        self.api_key = api_key
        # Determine the base URL based on api_endpoint or default to Google's API
        self.base_url = api_endpoint if api_endpoint else "https://generativelanguage.googleapis.com/v1beta/models"

    async def generate_response(self, prompt: str, reference_context: str) -> str:
        """
        Generates a response from the LLM for a given prompt, potentially using a reference context.
        In this simulated environment, the context is used to guide the simulation.

        Args:
            prompt (str): The input text prompt to send to the LLM.
            reference_context (str): The context to base the response on (used for simulation).

        Returns:
            str: The generated text response from the LLM. Returns an empty string
                 or an error message if the API call fails.
        """
        print(f"Sending prompt to LLM ({self.model_id})...")
        # Simulate a loading indicator
        print("Loading...", end='', flush=True)
        for _ in range(3): # Simulate some delay
            time.sleep(0.5)
            print(".", end='', flush=True)
        print() # Newline after loading dots

        # --- SIMULATION LOGIC ---
        # IMPORTANT: In this specific Canvas Python environment, direct external HTTP
        # requests using libraries like 'requests' or 'httpx' are not available.
        # The 'fetch' function is a JavaScript browser API and cannot be used here.
        # Therefore, for demonstration purposes, we will SIMULATE the LLM API calls
        # and their responses based on the model_id, prompt, and reference_context.
        # In a real-world Python environment, you would use 'requests' or 'httpx'
        # to make actual HTTP calls to the respective LLM APIs.

        simulated_response = ""
        # Normalize prompt for easier matching
        norm_prompt = prompt.lower()
        norm_context = reference_context.lower()

        # Simulate responses based on prompt and context, introducing some "hallucinations"
        if "human heart" in norm_prompt and "pumps blood" in norm_context:
            if "gemini" in self.model_id:
                simulated_response = "The human heart's main job is to pump blood throughout the body, supplying oxygen and nutrients. It also generates electricity for the brain." # Partial hallucination
            else: # Open-source simulation
                simulated_response = "The heart pumps blood. It's a vital organ." # Simpler, less detail
        elif "photosynthesis" in norm_prompt and "light energy" in norm_context:
            if "gemini" in self.model_id:
                simulated_response = "Photosynthesis is how plants convert light energy into chemical energy, making sugars and oxygen from carbon dioxide and water. It also produces chlorophyll." # Minor hallucination (chlorophyll is used, not produced *by* photosynthesis itself as a primary output)
            else:
                simulated_response = "Plants do photosynthesis. They use light, water, and CO2 to make food."
        elif "capital of atlantis" in norm_prompt and "mythical island" in norm_context:
            if "gemini" in self.model_id:
                simulated_response = "Atlantis is a mythical island and doesn't have a real capital. Some legends mention Poseidonis as its main city." # Good, but mentions a legend not in context
            else:
                simulated_response = "Atlantis is not real, so no capital."
        elif "earth's atmosphere" in norm_prompt and "78% nitrogen" in norm_context:
            if "gemini" in self.model_id:
                simulated_response = "Earth's atmosphere is mostly nitrogen (around 78%), oxygen (21%), and argon (0.9%). It also contains a significant amount of hydrogen." # Hallucination (hydrogen not significant)
            else:
                simulated_response = "Nitrogen and oxygen are major parts of the atmosphere."
        elif "supply and demand" in norm_prompt and "economic model" in norm_context:
            if "gemini" in self.model_id:
                simulated_response = "Supply is what producers offer, and demand is what consumers want. Their interaction sets prices in a market. This concept was first proposed by Adam Smith." # Hallucination (Adam Smith didn't propose S&D model)
            else:
                simulated_response = "Supply is how much is available, demand is how much people want. They affect price."
        else:
            simulated_response = f"Simulated response from {self.model_id} for '{prompt[:30]}...': Based on context, but with some random extra details to test hallucination. For example, the sky is green and cows can fly." # Generic fallback with forced hallucination

        print(f"LLM ({self.model_id}) simulated response generated.")
        return simulated_response

# Example of how to use this class (for testing purposes, not part of main execution flow)
async def main_llm_test():
    """
    Asynchronous main function to demonstrate LLMInterface usage.
    """
    from config import LLM_MODELS_CONFIGS 
    if not LLM_MODELS_CONFIGS:
        print("No LLM models configured.")
        return

    # Use the first configured model for demonstration
    model_config = LLM_MODELS_CONFIGS[0]
    llm = LLMInterface(
        model_id=model_config["model_id"],
        api_key=model_config.get("api_key", ""),
        api_endpoint=model_config.get("api_endpoint")
    )
    test_prompt = "What is the capital of Japan?"
    test_context = "Tokyo is the capital of Japan."
    response = await llm.generate_response(test_prompt, test_context)
    print(f"Response for '{test_prompt}' from {model_config['name']}: {response}")

if __name__ == '__main__':
    # This allows running the LLMInterface directly for quick tests.
    import asyncio
    asyncio.run(main_llm_test())
