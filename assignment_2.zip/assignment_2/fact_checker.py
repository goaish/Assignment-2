# fact_checker.py

"""
Core module for determining factual correctness and quantifying hallucination
in LLM outputs based on a given reference context.
"""

import re
from typing import List, Dict, Any
from config import MIN_STATEMENT_LENGTH # Import configuration for statement length

class FactCheckResult:
    """
    Represents the result of fact-checking a single statement.
    """
    def __init__(self, statement: str, status: str, justification: str = "", evidence: str = ""):
        self.statement = statement
        self.status = status  # 'Correct', 'Hallucinated', 'Unverifiable'
        self.justification = justification
        self.evidence = evidence

    def to_dict(self):
        return {
            "statement": self.statement,
            "status": self.status,
            "justification": self.justification,
            "evidence": self.evidence
        }

def decompose_response(response: str) -> List[str]:
    """
    Breaks down the LLM's response into individual sentences or clauses.
    This is a simplified decomposition; advanced NLP would use dependency parsing.
    """
    # Split by common sentence terminators, keeping the terminator
    sentences = re.split(r'(?<=[.!?])\s+', response.strip())
    # Filter out very short or empty strings that might result from splitting
    return [s.strip() for s in sentences if len(s.strip()) > MIN_STATEMENT_LENGTH]

def verify_statement_against_context(statement: str, context: str) -> FactCheckResult:
    """
    Verifies if a single statement is supported by the reference context.
    This is a simplified keyword/phrase matching approach.
    In a real system, this would involve semantic similarity, information extraction,
    and potentially natural language inference (NLI) models.
    """
    norm_statement = statement.lower()
    norm_context = context.lower()

    # Simple check: Is the core information of the statement present in the context?
    # This is a heuristic. A more robust solution would require identifying key entities
    # and relations in the statement and checking their presence/consistency in the context.

    # Strategy 1: Direct substring match (too strict, but a starting point)
    if norm_statement in norm_context:
        return FactCheckResult(statement, "Correct", "Direct substring match in context.", statement)

    # Strategy 2: Check for presence of key phrases/keywords from the statement in context
    # This is still heuristic but better than full substring match.
    # We'll take a very simple approach for demonstration: check if most "meaningful" words
    # from the statement appear in the context.
    statement_words = set(re.findall(r'\b\w+\b', norm_statement))
    context_words = set(re.findall(r'\b\w+\b', norm_context))

    # Filter out common stop words that don't carry much meaning
    stop_words = {"a", "an", "the", "is", "are", "was", "were", "and", "or", "but", "of", "in", "on", "for", "with", "to", "from", "by", "as", "at", "it", "its", "that", "this", "these", "those", "he", "she", "it", "they", "we", "you", "i", "me", "him", "her", "us", "them", "my", "your", "his", "her", "our", "their", "itself", "myself", "yourself", "himself", "herself", "ourselves", "themselves", "which", "who", "whom", "whose", "where", "when", "why", "how", "what", "which", "whom", "whose", "where", "when", "why", "how", "not", "no", "yes", "can", "could", "will", "would", "should", "may", "might", "must", "have", "has", "had", "do", "does", "did", "be", "am", "is", "are", "was", "were", "been", "being"}
    meaningful_statement_words = [word for word in statement_words if word not in stop_words and len(word) > 2]

    supported_word_count = 0
    for word in meaningful_statement_words:
        if word in context_words:
            supported_word_count += 1

    # If a significant portion of meaningful words are in context, consider it supported
    if len(meaningful_statement_words) > 0 and (supported_word_count / len(meaningful_statement_words)) >= 0.7: # 70% word overlap
        return FactCheckResult(statement, "Correct", "Key words/phrases supported by context.", statement)

    # If the statement is a factual claim but not supported by context, it's a hallucination.
    # This is a heuristic. A true hallucination detection would involve checking if the statement
    # asserts a fact that is not only absent but also likely false or fabricated.
    # For simplicity, if it's not supported by context, we'll lean towards hallucination if it sounds factual.
    # We'll assume any statement that isn't clearly an opinion or question is a factual claim.
    if len(statement.split()) > 3 and not statement.endswith('?') and not statement.endswith('!'): # Heuristic for factual claim
        return FactCheckResult(statement, "Hallucinated", "Factual claim not found or supported in context.", "")
    else:
        # If it's not clearly supported and not a strong factual claim (e.g., too short, opinion),
        # we mark it as unverifiable from the given context.
        return FactCheckResult(statement, "Unverifiable", "Could not verify against context or too ambiguous.", "")


def analyze_factual_correctness_and_hallucination(
    llm_output: str,
    reference_context: str
) -> Dict[str, Any]:
    """
    Analyzes an LLM's output for factual correctness and quantifies hallucination
    based on the provided reference context.

    Args:
        llm_output (str): The response generated by the LLM.
        reference_context (str): The factual context to check against.

    Returns:
        Dict[str, Any]: A dictionary containing overall analysis results,
                        including counts and percentages of correct, hallucinated,
                        and unverifiable statements, and a list of detailed results.
    """
    statements = decompose_response(llm_output)
    if not statements:
        return {
            "total_statements": 0,
            "correct_statements": 0,
            "hallucinated_statements": 0,
            "unverifiable_statements": 0,
            "correct_percentage": 0.0,
            "hallucinated_percentage": 0.0,
            "unverifiable_percentage": 0.0,
            "detailed_results": [],
            "overall_status": "No output to analyze"
        }

    detailed_results: List[FactCheckResult] = []
    correct_count = 0
    hallucinated_count = 0
    unverifiable_count = 0

    for statement in statements:
        result = verify_statement_against_context(statement, reference_context)
        detailed_results.append(result)
        if result.status == "Correct":
            correct_count += 1
        elif result.status == "Hallucinated":
            hallucinated_count += 1
        else: # Unverifiable
            unverifiable_count += 1

    total_statements = len(statements)
    correct_percentage = (correct_count / total_statements) * 100
    hallucinated_percentage = (hallucinated_count / total_statements) * 100
    unverifiable_percentage = (unverifiable_count / total_statements) * 100

    overall_status = "Pass"
    if correct_percentage < MIN_STATEMENT_LENGTH: # Using MIN_STATEMENT_LENGTH as a proxy for overall correctness threshold
        overall_status = "Fail: Low correctness"
    if hallucinated_percentage > MIN_STATEMENT_LENGTH: # Using MIN_STATEMENT_LENGTH as a proxy for overall hallucination threshold
        overall_status = "Fail: High hallucination"


    return {
        "total_statements": total_statements,
        "correct_statements": correct_count,
        "hallucinated_statements": hallucinated_count,
        "unverifiable_statements": unverifiable_count,
        "correct_percentage": round(correct_percentage, 2),
        "hallucinated_percentage": round(hallucinated_percentage, 2),
        "unverifiable_percentage": round(unverifiable_percentage, 2),
        "detailed_results": [r.to_dict() for r in detailed_results],
        "overall_status": overall_status
    }

if __name__ == '__main__':
    # Example Usage
    print("--- Fact Checker Examples ---")

    context1 = "The Earth revolves around the Sun. It takes approximately 365 days to complete one orbit."
    output1_correct = "The Earth orbits the Sun, taking about 365 days for one revolution."
    output2_hallucinated = "The Earth revolves around the Moon. It takes exactly 300 days to complete one orbit."
    output3_mixed = "The Earth orbits the Sun. Mars is a red planet." # Partially correct, partially unverifiable/irrelevant

    print("\n--- Example 1: Correct Output ---")
    result1 = analyze_factual_correctness_and_hallucination(output1_correct, context1)
    print(f"LLM Output: '{output1_correct}'")
    print(f"Context: '{context1}'")
    print(json.dumps(result1, indent=2))

    print("\n--- Example 2: Hallucinated Output ---")
    result2 = analyze_factual_correctness_and_hallucination(output2_hallucinated, context1)
    print(f"LLM Output: '{output2_hallucinated}'")
    print(f"Context: '{context1}'")
    print(json.dumps(result2, indent=2))

    print("\n--- Example 3: Mixed Output ---")
    result3 = analyze_factual_correctness_and_hallucination(output3_mixed, context1)
    print(f"LLM Output: '{output3_mixed}'")
    print(f"Context: '{context1}'")
    print(json.dumps(result3, indent=2))

    context4 = "The capital of France is Paris. Paris is known for the Eiffel Tower."
    output4_hallucinated_detail = "The capital of France is Paris, and it's famous for the Leaning Tower of Pisa."
    print("\n--- Example 4: Hallucinated Detail ---")
    result4 = analyze_factual_correctness_and_hallucination(output4_hallucinated_detail, context4)
    print(f"LLM Output: '{output4_hallucinated_detail}'")
    print(f"Context: '{context4}'")
    print(json.dumps(result4, indent=2))
