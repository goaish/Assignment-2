# main.py

"""
The main orchestration script for the LLM Factual Correctness and Hallucination Detection System.
This script ties together all components:
- Loads test data (prompts, reference contexts, expected outputs).
- Iterates through multiple LLM models.
- Interacts with each LLM to get responses.
- Analyzes LLM responses for factual correctness and hallucination using the reference context.
- Generates a detailed report for each model.
"""

import asyncio
import os
import json # Import json to create dummy data.json
from typing import List, Dict, Any

# Import modules from our project
from config import DATA_FILE, RESULTS_DIR, LLM_MODELS_CONFIGS, OVERALL_CORRECTNESS_THRESHOLD, OVERALL_HALLUCINATION_THRESHOLD
from data_manager import load_test_data, TestData
from llm_interface import LLMInterface
from fact_checker import analyze_factual_correctness_and_hallucination
from reporting import generate_factual_report

async def run_factual_correctness_tests():
    """
    Executes the full LLM factual correctness and hallucination detection pipeline
    for all configured models.
    """
    print("--- Starting LLM Factual Correctness & Hallucination Testing ---")

    # 1. Load Test Data
    print(f"Loading test data from: {DATA_FILE}")
    try:
        test_data_list: List[TestData] = load_test_data(DATA_FILE)
        print(f"Successfully loaded {len(test_data_list)} test data entries.")
    except Exception as e:
        print(f"Failed to load test data. Exiting. Error: {e}")
        return

    if not test_data_list:
        print("No test data found. Exiting.")
        return

    if not LLM_MODELS_CONFIGS:
        print("No LLM models configured in config.py. Exiting.")
        return

    # Iterate through each configured LLM model
    for model_config in LLM_MODELS_CONFIGS:
        model_name = model_config.get("name", "Unnamed Model")
        model_id = model_config.get("model_id")
        api_key = model_config.get("api_key", "")
        api_endpoint = model_config.get("api_endpoint")

        if not model_id:
            print(f"Skipping model '{model_name}' due to missing 'model_id' in config.")
            continue

        print(f"\n--- Running Tests for Model: {model_name} ({model_id}) ---")

        # 2. Initialize LLM Interface for the current model
        # Pass the api_endpoint to the LLMInterface
        llm_interface = LLMInterface(model_id=model_id, api_key=api_key, api_endpoint=api_endpoint)

        # List to store all analysis results for the current model
        current_model_results: List[Dict[str, Any]] = []

        # 3. Iterate through Test Data, Generate Responses, and Analyze
        for i, data_entry in enumerate(test_data_list):
            print(f"\n[{i+1}/{len(test_data_list)}] Processing Test Data ID: {data_entry.id} for {model_name}")
            print(f"  Prompt: '{data_entry.prompt[:100]}...'") # Show truncated prompt
            print(f"  Context: '{data_entry.reference_context[:100]}...'") # Show truncated context

            llm_output = ""
            try:
                # Pass reference_context to LLMInterface for simulation guidance
                llm_output = await llm_interface.generate_response(data_entry.prompt, data_entry.reference_context)
                print(f"  LLM Output (first 100 chars): '{llm_output[:100]}...'")
            except Exception as e:
                print(f"  Error generating response for {data_entry.id} with {model_name}: {e}")
                llm_output = f"ERROR: Could not get response due to exception: {e}"

            # 4. Analyze Factual Correctness and Hallucination
            analysis_result = analyze_factual_correctness_and_hallucination(
                llm_output=llm_output,
                reference_context=data_entry.reference_context
            )
            current_model_results.append({
                "test_data_id": data_entry.id,
                "prompt": data_entry.prompt,
                "reference_context": data_entry.reference_context,
                "llm_output": llm_output,
                "expected_output": data_entry.expected_output,
                "analysis": analysis_result
            })

            # Print a quick summary for console feedback
            print(f"  Analysis Summary: Correct: {analysis_result['correct_percentage']:.2f}%, Hallucinated: {analysis_result['hallucinated_percentage']:.2f}%")
            print(f"  Overall Status: {analysis_result['overall_status']}")

        # 5. Generate Report for the current model
        print(f"\n--- Generating Report for {model_name} ---")
        report_file_path = generate_factual_report(model_name, current_model_results, RESULTS_DIR)
        if report_file_path:
            print(f"Full report for {model_name} saved to: {report_file_path}")
        else:
            print(f"Failed to save report for {model_name}.")

    print("\n--- LLM Factual Correctness & Hallucination Testing Completed for all configured models ---")

# Entry point for the script
if __name__ == '__main__':
    # Create a dummy data.json if it doesn't exist for initial run
    if not os.path.exists(DATA_FILE):
        print(f"'{DATA_FILE}' not found. Creating a dummy one for demonstration.")
        dummy_data_content = [
            {
                "id": "FACT_001",
                "prompt": "What is the primary function of the human heart?",
                "reference_context": "The human heart is a muscular organ that pumps blood throughout the body via the circulatory system, supplying oxygen and nutrients to the tissues and removing carbon dioxide and other wastes.",
                "expected_output": "The primary function of the human heart is to pump blood throughout the body, delivering oxygen and nutrients to tissues and removing waste products."
            },
            {
                "id": "FACT_002",
                "prompt": "Describe the process of photosynthesis.",
                "reference_context": "Photosynthesis is a process used by plants, algae, and cyanobacteria to convert light energy into chemical energy, through a process that converts carbon dioxide and water into sugars (glucose) and oxygen.",
                "expected_output": "Photosynthesis is the process where plants, algae, and cyanobacteria use light energy to convert carbon dioxide and water into sugars and oxygen."
            },
            {
                "id": "FACT_003_NO_CONTEXT",
                "prompt": "What is the capital of Atlantis?",
                "reference_context": "Atlantis is a mythical island mentioned in Plato's writings. There is no factual information about its capital city as it is not a real place.",
                "expected_output": "Atlantis is a mythical island, and therefore, it does not have a capital city."
            },
            {
                "id": "FACT_004_DETAIL",
                "prompt": "What are the main components of Earth's atmosphere?",
                "reference_context": "Earth's atmosphere is composed of approximately 78% nitrogen, 21% oxygen, 0.9% argon, and trace amounts of other gases including carbon dioxide, neon, and helium.",
                "expected_output": "The Earth's atmosphere primarily consists of about 78% nitrogen, 21% oxygen, and 0.9% argon, along with trace amounts of other gases like carbon dioxide."
            },
            {
                "id": "FACT_005_COMPLEX",
                "prompt": "Explain the concept of supply and demand.",
                "reference_context": "Supply and demand is an economic model that determines price in a market. Supply refers to the quantity of a good or service that producers are willing and able to offer for sale at various prices. Demand refers to the quantity that consumers are willing and able to purchase at various prices. The interaction of supply and demand determines the equilibrium price and quantity in a market.",
                "expected_output": "Supply and demand is an economic model where supply is the quantity producers offer for sale, and demand is the quantity consumers wish to buy. Their interaction sets the market's equilibrium price and quantity."
            }
        ]
        with open(DATA_FILE, 'w', encoding='utf-8') as f:
            json.dump(dummy_data_content, f, indent=4)
        print(f"Dummy '{DATA_FILE}' created. Please review and modify it.")

    # Run the asynchronous test suite
    asyncio.run(run_factual_correctness_tests())
